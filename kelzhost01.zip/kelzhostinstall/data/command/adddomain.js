const fs = require("fs");
const { prefix } = require("../../setting");
const axios = require("axios");

async function addDomain(kelzhost, sender, text) {
  const domainData = text.trim().split('|'); // Asumsikan formatnya: nama_domain|ipvps

  if (domainData.length !== 2) {
    // Jika format tidak benar, beri tahu pengguna
    await kelzhost.sendMessage(sender, { text: `❌ *Format yang benar*: ${prefix}adddomain <nama_domain>|<ipvps>` });
    return;
  }

  const domainName = domainData[0].trim();
  const ipvps = domainData[1].trim();

  if (!domainName || !ipvps) {
    // Jika nama domain atau IP VPS kosong
    await kelzhost.sendMessage(sender, { text: `⚠️ *Harap masukkan nama domain dan IP VPS dengan benar.*` });
    return;
  }

  const filePath = "./data/domains.json";
  let domains = [];

  try {
    // Jika file domains.json sudah ada, baca datanya
    if (fs.existsSync(filePath)) {
      const data = await fs.promises.readFile(filePath, "utf8");
      domains = JSON.parse(data);
    }

    // Memeriksa apakah domain sudah ada
    let existingDomain = domains.find(domain => domain.name === domainName);
    if (existingDomain) {
      // Jika domain sudah ada, lanjutkan dengan menambahkan subdomain
      await kelzhost.sendMessage(sender, { text: `⚠️ Domain *"${domainName}"* sudah terdaftar. Anda dapat menambahkan subdomain untuk domain ini.` });
      return;
    }

    // Menambahkan domain baru
    domains.push({ name: domainName, ipvps: ipvps, subdomains: [] });

    // Menyimpan daftar domain yang sudah diperbarui
    await fs.promises.writeFile(filePath, JSON.stringify(domains, null, 2), "utf8");

    // Menentukan zona dan token untuk masing-masing domain
    let domainZone = "";
    let apiToken = "";
    let tld = "";

    switch(domainName) {
      case 'domain1':
        domainZone = "80bb373d8fbd32d5e9eb5c173d7958cf";
        apiToken = "PrrlP5uUP4xCCo2GQnFWZ6jklJEuIloNx1L_wihX";
        tld = "panel-private-vvip.web.id";
        break;
      case 'domain2':
        domainZone = "d043640d2a9a4ac23c237f26c42f8ecd";
        apiToken = "oJZRLcXIi6NuLCX1CCFAGtuu8k4UOIgRUrlwQdyC";
        tld = "websiteoffcial.my.id";
        break;
      case 'domain3':
        domainZone = "9e5258532f08ffe71c44990d6619a187";
        apiToken = "FSkid5Sdk9Hkp8i-bN5nYek8mtycpaChyZ7D4ZeG";
        tld = "website-private.my.id";
        break;
      case 'domain4':
        domainZone = "4d8cbc3cfd69f987579f8b1e1ea18813";
        apiToken = "lPImJRkjbyQ9sYTo0d3cFsCWMsA9PqhY_KYckNw7";
        tld = "viki-vvip-panel.my.id";
        break;
      default:
        return kelzhost.sendMessage(sender, { text: `⚠️ Domain tidak valid` });
    }

    // Fungsi untuk menambahkan subdomain melalui API Cloudflare
    function addSubDomain(host, ip) {
      return new Promise((resolve) => {
        axios.post(
          `https://api.cloudflare.com/client/v4/zones/${domainZone}/dns_records`,
          {
            type: "A",
            name: `${host}.${tld}`,
            content: ip,
            ttl: 3600,
            priority: 10,
            proxied: false
          },
          {
            headers: {
              Authorization: `Bearer ${apiToken}`,
              "Content-Type": "application/json"
            }
          }
        ).then((response) => {
          const res = response.data;
          if (res.success) {
            resolve({
              success: true,
              ip: res.result.content,
              name: res.result.name
            });
          } else {
            resolve({
              success: false,
              error: res.errors || "Unknown error"
            });
          }
        }).catch((error) => {
          resolve({
            success: false,
            error: error.response?.data?.errors?.[0]?.message || error.message
          });
        });
      });
    }

    // Menambahkan subdomain
    const rawData = text.split("|");
    const host = rawData[0].trim();
    const ip = rawData[1].trim();

    if (!host || !ip) {
      return kelzhost.sendMessage(sender, { text: `⚠️ Format subdomain salah. Pastikan formatnya benar: hostname|IP` });
    }

    addSubDomain(host, ip).then((response) => {
      if (response.success) {
        kelzhost.sendMessage(sender, {
          text: `📢 *Subdomain berhasil ditambahkan!*\n\n🌐 *Nama Domain:* ${domainName}\n💻 *IP VPS:* ${ipvps}\nSubdomain *${host}.${tld}* telah berhasil ditambahkan dengan IP *${response.ip}*`
        });
      } else {
        kelzhost.sendMessage(sender, { text: `❌ Gagal menambahkan subdomain. Error: ${response.error}` });
      }
    });

  } catch (error) {
    console.log("Error dalam menambah domain:", error);
    kelzhost.sendMessage(sender, { text: "❌ *Terjadi kesalahan saat menambahkan domain. Coba lagi nanti.*" });
  }
}

module.exports = { addDomain };