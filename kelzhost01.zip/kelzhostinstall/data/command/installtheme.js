const { Client } = require('ssh2');
const { kelzhost } = require('./kelzhost'); // pastikan kelzhost sudah di set up dengan benar
const { themeInstallCommands } = require('../../setting'); // Mengimpor file setting.js yang berisi perintah instalasi tema

async function installTheme(kelzhost, sender, text) {
    const t = text.split(',');
    if (t.length < 2) {
        return kelzhost.sendMessage(sender, { text: `*Format salah!*\nPenggunaan: ${prefix}installtheme ipvps,password` });
    }

    const ipvps = t[0];
    const passwd = t[1];

    // Membuat pengaturan koneksi SSH
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    // Koneksi SSH ke VPS
    const conn = new Client();
    
    conn.on('ready', () => {
        kelzhost.sendMessage(sender, { text: '`PROSES PENGINSTALLAN THEME TUNGGU YA GA SABARAN`' });

        // Menampilkan pilihan tema
        const sections = [{
            title: 'Silahkan Pilih Theme Yang Ingin Di Install',
            rows: [{
                title: 'INSTALL THEME STELLAR',
                id: `.th1 ${ipvps},${passwd}`
            },
            {
                title: 'INSTALL THEME BILLING',
                id: `.th2 ${ipvps},${passwd}`
            },
            {
                title: 'INSTALL THEME ENIGMA',
                id: `.th3 ${ipvps},${passwd}`
            }]
        }];

        const listMessage = {
            title: 'Klik Disini!',
            sections
        };

        kelzhost.sendMessage(sender, {
            interactiveMessage: listMessage
        });

    }).connect(connSettings);
    
    // Fungsi untuk menginstal tema
    async function installSelectedTheme(conn, themeName) {
        let command = '';

        // Menentukan perintah berdasarkan tema yang dipilih
        switch (themeName) {
            case 'th1':
                command = themeInstallCommands.stellar; // Perintah instalasi untuk theme stellar
                break;
            case 'th2':
                command = themeInstallCommands.billing; // Perintah instalasi untuk theme billing
                break;
            case 'th3':
                command = themeInstallCommands.enigma; // Perintah instalasi untuk theme enigma
                break;
            default:
                kelzhost.sendMessage(sender, { text: 'Tema tidak ditemukan!' });
                return;
        }

        // Eksekusi perintah untuk menginstal tema
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log(`Tema ${themeName} instalasi selesai dengan kode ${code} dan sinyal ${signal}`);
                kelzhost.sendMessage(sender, { text: `Tema ${themeName} berhasil diinstal!` });
                conn.end();
            }).on('data', (data) => {
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }

    // Menangani tema yang dipilih
    kelzhost.on('message', (message) => {
        if (message.command && message.command.startsWith('.th')) {
            const theme = message.command.split(' ')[0]; // Mengambil tema berdasarkan input pengguna
            installSelectedTheme(conn, theme);
        }
    });
}

module.exports = { installTheme };