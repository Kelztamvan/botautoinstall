const fs = require('fs');
const path = require('path');

// Fungsi untuk menambah reseller
async function addReseller(kelzhost, sender, text) {
  const nomor = text.split(' ')[1]; // Mengambil nomor dari perintah
  if (!nomor) {
    return kelzhost.sendMessage(sender, { text: "⚠️ Harap masukkan nomor reseller yang valid setelah perintah!" });
  }

  const resellers = await getResellers(); // Ambil daftar reseller yang ada
  if (resellers.length >= 15) {
    return kelzhost.sendMessage(sender, { text: "⚠️ Anda sudah mencapai batas maksimal reseller (15)." });
  }

  // Tambahkan reseller baru
  const newReseller = {
    id: sender,
    nomor: nomor
  };
  resellers.push(newReseller);
  
  // Simpan data reseller yang telah diperbarui
  await saveResellers(resellers);

  return kelzhost.sendMessage(sender, { text: `✅ Reseller dengan nomor ${nomor} berhasil ditambahkan.` });
}

// Fungsi untuk mengambil daftar reseller
async function getResellers() {
  const resellerFile = path.join(__dirname, 'data', 'reseller.json');
  if (fs.existsSync(resellerFile)) {
    return JSON.parse(fs.readFileSync(resellerFile));
  }
  return [];
}

// Fungsi untuk menyimpan data reseller ke dalam file
async function saveResellers(resellers) {
  const resellerFile = path.join(__dirname, 'data', 'reseller.json');
  fs.writeFileSync(resellerFile, JSON.stringify(resellers, null, 2));
}

module.exports = { addReseller };