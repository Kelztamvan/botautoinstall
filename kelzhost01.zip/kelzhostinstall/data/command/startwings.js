const { Client } = require('ssh2');
const { generateRandomPassword } = require('../helpers/password'); // Menghasilkan password acak
const { bash } = require('../../setting'); // Mengimpor file setting.js

// Fungsi pengiriman pesan
async function sendMessage(sender, message) {
    // Ganti dengan pengiriman pesan yang sesuai
    console.log(`Kepada: ${sender} - ${message.text}`);
}

// Fungsi untuk memulai Wings di VPS
async function startWings(sender, text) {
    const t = text.split(',');
    if (t.length < 3) {
        return sendMessage(sender, { text: `*Format salah!*\nPenggunaan: ${prefix}startwings vps,passwordvps,tokengeneration (Contoh: 192.168.1.1, password123, 1234567890abcdef)` });
    }

    const vps = t[0];            // IP VPS
    const passwdvps = t[1];      // Password VPS
    const token = t[2];          // Token yang dihasilkan

    // Konfigurasi koneksi SSH ke VPS
    const connSettings = {
        host: vps,
        port: '22',
        username: 'root',
        password: passwdvps,
    };

    // Generate password acak untuk panel atau Wings (sesuai kebutuhan)
    const randomPassword = generateRandomPassword();

    // Perintah untuk memulai Wings dengan token yang diberikan
    const commandStartWings = `bash <(curl -s https://pterodactyl-installer.se) start ${token}`;

    const conn = new Client();

    // Menghubungkan ke VPS
    conn.on('ready', () => {
        sendMessage(sender, { text: '`PROSES START WINGS TUNGGU YA MANIEZ`' });

        // Eksekusi perintah untuk memulai Wings
        conn.exec(commandStartWings, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Wings start stream closed with code ' + code + ' and signal ' + signal);
                sendMessage(sender, { text: '`WINGS BERHASIL DIMULAI!`' });
                conn.end();
            }).on('data', (data) => {
                handleStartWingsInput(data, stream, token);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).connect(connSettings);

    // Fungsi untuk menangani input dalam proses instalasi Wings
    function handleStartWingsInput(data, stream, token) {
        if (data.toString().includes('Input')) { 
            stream.write(`${token}\n`);  // Kirimkan token untuk memulai Wings
        }
        console.log('STDOUT: ' + data);
    }
}

// Fungsi untuk generate password acak (misalnya untuk panel)
function generateRandomPassword() {
    const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-+=<>?";
    let password = "";
    for (let i = 0; i < 16; i++) {
        password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
}

module.exports = { startWings, generateRandomPassword };