const fs = require('fs');
const path = require('path');

// Fungsi untuk memeriksa apakah reseller terdaftar
async function checkReseller(kelzhost, sender, text) {
  const nomor = text.split(' ')[1]; // Mengambil nomor dari perintah
  if (!nomor) {
    return kelzhost.sendMessage(sender, { text: "⚠️ Harap masukkan nomor reseller yang valid setelah perintah!" });
  }

  const resellers = await getResellers(); // Ambil daftar reseller yang ada
  const reseller = resellers.find(r => r.nomor === nomor); // Cari reseller berdasarkan nomor

  if (reseller) {
    return kelzhost.sendMessage(sender, { text: `✅ Reseller dengan nomor ${nomor} ditemukan.` });
  } else {
    return kelzhost.sendMessage(sender, { text: `⚠️ Reseller dengan nomor ${nomor} tidak ditemukan.` });
  }
}

// Fungsi untuk mengambil daftar reseller
async function getResellers() {
  const resellerFile = path.join(__dirname, 'data', 'reseller.json');
  if (fs.existsSync(resellerFile)) {
    return JSON.parse(fs.readFileSync(resellerFile));
  }
  return [];
}

module.exports = { checkReseller };