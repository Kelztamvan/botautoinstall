const { Client } = require('ssh2');
const { generateRandomPassword } = require('../helpers/password');
const { kelzhost } = require('./kelzhost'); // pastikan kelzhost sudah di set up dengan benar
const { bash } = require('../../setting'); // Mengimpor file setting.js

async function installPterodactylPanel(kelzhost, sender, text) {
    const t = text.split(',');
    if (t.length < 5) {
        return kelzhost.sendMessage(sender, { text: `*Format salah!*\nPenggunaan: ${prefix}installpanel1 ipvps,password,domainpnl,domainnode,ramvps (Contoh 80000 8gb)` });
    }

    const ipvps = t[0];
    const passwd = t[1];
    const subdomain = t[2];
    const domainnode = t[3];
    const ramvps = t[4];
    
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const password = generateRandomPassword(); // Password acak untuk panel
    const commandPanel = 'bash <(curl -s https://pterodactyl-installer.se)';
    const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
    const conn = new Client();

    conn.on('ready', () => {
        kelzhost.sendMessage(sender, { text: '`PROSES PENGINSTALLAN PANEL TUNGGU YA GA SABARAN TAK KOKOP`' });
        conn.exec(commandPanel, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Panel installation stream closed with code ' + code + ' and signal ' + signal);
                installWings(conn, domainnode, subdomain, password, ramvps);
            }).on('data', (data) => {
                handlePanelInstallationInput(data, stream, subdomain, password);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).connect(connSettings);

    async function installWings(conn, domainnode, subdomain, password, ramvps) {
        kelzhost.sendMessage(sender, { text: '`PROSES PENGINSTALLAN WINGS TUNGGU YA MANIEZ`' });
        conn.exec(commandWings, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Wings installation stream closed with code ' + code + ' and signal ' + signal);
                createNode(conn, domainnode, ramvps, subdomain, password);
            }).on('data', (data) => {
                handleWingsInstallationInput(data, stream, domainnode, subdomain);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }

    async function createNode(conn, domainnode, ramvps, subdomain, password) {
        const command = bash; // Menggunakan path dari setting.js
        kelzhost.sendMessage(sender, { text: '`MEMULAI CREATE NODE & LOCATION`' });

        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Node creation stream closed with code ' + code + ' and signal ' + signal);
                conn.end();
                sendPanelData(subdomain, password);
            }).on('data', (data) => {
                handleNodeCreationInput(data, stream, domainnode, ramvps);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }

    function sendPanelData(subdomain, password) {
        kelzhost.sendMessage(sender, { text: `*DATA PANEL ANDA*\n\n*USERNAME:* admin\n*PASSWORD:* ${password}\n*LOGIN:* ${subdomain}\n\nNote: Semua Instalasi Telah Selesai Silahkan Create Allocation Di Node Yang Di buat Oleh Bot Dan Ambil Token Configuration dan ketik .startwings (token) \nNote: *HARAP TUNGGU 1-5MENIT BIAR WEB BISA DI BUKA*` });
    }

    function handlePanelInstallationInput(data, stream, subdomain, password) {
        if (data.toString().includes('Input')) { stream.write('0\n'); }
        if (data.toString().includes('Input')) { stream.write('\n'); }
        if (data.toString().includes('Input')) { stream.write('Asia/Jakarta\n'); }
        if (data.toString().includes('Input')) { stream.write('admin@gmail.com\n'); } // Email admin
        if (data.toString().includes('Input')) { stream.write('admin\n'); } // Username admin
        if (data.toString().includes('Input')) { stream.write(`${password}\n`); } // Password
        if (data.toString().includes('Input')) { stream.write(`${subdomain}\n`); }
        console.log('STDOUT: ' + data);
    }

    function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
        if (data.toString().includes('Input')) { stream.write('1\n'); }
        if (data.toString().includes('Input')) { stream.write(`${subdomain}\n`); } // Subdomain
        if (data.toString().includes('Input')) { stream.write('user\n'); } // Username
        if (data.toString().includes('Input')) { stream.write(`${domainnode}\n`); } // Domain node
        console.log('STDOUT: ' + data);
    }

    function handleNodeCreationInput(data, stream, domainnode, ramvps) {
        stream.write(`${global.tokeninstall}\n`);
        stream.write('4\n');
        stream.write('SGP\n');
        stream.write('Jangan Lupa Support KELZHOSTING🦅🇮🇩\n');
        stream.write(`${domainnode}\n`);
        stream.write('NODES\n');
        stream.write(`${ramvps}\n`);
        console.log('STDOUT: ' + data);
    }
}

module.exports = { installPterodactylPanel };