const fs = require('fs');
const path = require('path');

// Fungsi untuk menghapus reseller
async function removeReseller(kelzhost, sender, text) {
  const nomor = text.split(' ')[1]; // Mengambil nomor dari perintah
  if (!nomor) {
    return kelzhost.sendMessage(sender, { text: "⚠️ Harap masukkan nomor reseller yang valid setelah perintah!" });
  }

  const resellers = await getResellers(); // Ambil daftar reseller yang ada
  const resellerIndex = resellers.findIndex(r => r.nomor === nomor); // Cari reseller berdasarkan nomor

  if (resellerIndex !== -1) {
    // Hapus reseller dari daftar
    resellers.splice(resellerIndex, 1);
    await saveResellers(resellers); // Simpan perubahan ke file

    return kelzhost.sendMessage(sender, { text: `✅ Reseller dengan nomor ${nomor} telah dihapus.` });
  } else {
    return kelzhost.sendMessage(sender, { text: `⚠️ Reseller dengan nomor ${nomor} tidak ditemukan.` });
  }
}

// Fungsi untuk mengambil daftar reseller
async function getResellers() {
  const resellerFile = path.join(__dirname, 'data', 'reseller.json');
  if (fs.existsSync(resellerFile)) {
    return JSON.parse(fs.readFileSync(resellerFile));
  }
  return [];
}

// Fungsi untuk menyimpan daftar reseller setelah perubahan
async function saveResellers(resellers) {
  const resellerFile = path.join(__dirname, 'data', 'reseller.json');
  fs.writeFileSync(resellerFile, JSON.stringify(resellers, null, 2)); // Menyimpan data ke file
}

module.exports = { removeReseller };