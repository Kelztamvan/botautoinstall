const fs = require("fs");
const { prefix } = require("../../setting");

// Fungsi untuk menampilkan daftar domain
async function listDomain(kelzhost, sender) {
  const filePath = "./data/domains.json";
  let domains = [];

  try {
    if (fs.existsSync(filePath)) {
      const data = await fs.promises.readFile(filePath, "utf8");
      domains = JSON.parse(data);
    }

    if (domains.length === 0) {
      await kelzhost.sendMessage(sender, { text: "⚠️ Tidak ada domain yang terdaftar." });
      return;
    }

    // Menampilkan daftar domain yang tersedia
    let domainListMessage = "Pilih domain yang ingin Anda tambahkan subdomainnya:\n";
    domains.forEach((domain, index) => {
      domainListMessage += `┃ .domain${index + 1} ${domain.name}\n`;
    });

    domainListMessage += `\nUntuk memilih domain, ketik nomor domain (misalnya: 1, 2, 3, dst.).`;
    await kelzhost.sendMessage(sender, { text: domainListMessage });

  } catch (error) {
    console.log("Error membaca domain:", error);
    await kelzhost.sendMessage(sender, { text: "❌ Terjadi kesalahan saat memuat daftar domain." });
  }
}

// Fungsi untuk menambahkan subdomain ke domain yang dipilih
async function addSubdomain(kelzhost, sender, text) {
  const selectedDomainIndex = parseInt(text.trim()) - 1; // Mengambil nomor domain yang dipilih
  const filePath = "./data/domains.json";
  let domains = [];

  if (isNaN(selectedDomainIndex)) {
    await kelzhost.sendMessage(sender, { text: "⚠️ Masukkan nomor domain yang valid." });
    return;
  }

  try {
    if (fs.existsSync(filePath)) {
      const data = await fs.promises.readFile(filePath, "utf8");
      domains = JSON.parse(data);
    }

    const selectedDomain = domains[selectedDomainIndex];
    if (!selectedDomain) {
      await kelzhost.sendMessage(sender, { text: "⚠️ Domain yang dipilih tidak ditemukan." });
      return;
    }

    // Meminta pengguna untuk memasukkan subdomain dan IP VPS
    await kelzhost.sendMessage(sender, { text: `📝 Masukkan nama subdomain dan IP VPS dengan format: subdomain|ipvps` });
    
    // Tangani input subdomain dan IP VPS setelahnya
    kelzhost.on('message', async (message) => {
      const subdomainData = message.text.trim().split('|');
      if (subdomainData.length !== 2) {
        await kelzhost.sendMessage(sender, { text: "❌ Format yang benar: subdomain|ipvps" });
        return;
      }

      const subdomain = subdomainData[0].trim();
      const ipvps = subdomainData[1].trim();

      // Memeriksa apakah subdomain sudah ada
      const existingSubdomain = selectedDomain.subdomains.some(sub => sub.subdomain === subdomain);
      if (existingSubdomain) {
        await kelzhost.sendMessage(sender, { text: `⚠️ Subdomain ${subdomain} sudah terdaftar di domain ${selectedDomain.name}.` });
        return;
      }

      // Menambahkan subdomain ke dalam domain
      selectedDomain.subdomains.push({ subdomain: subdomain, ipvps: ipvps });

      // Menyimpan data yang telah diperbarui
      await fs.promises.writeFile(filePath, JSON.stringify(domains, null, 2), "utf8");

      await kelzhost.sendMessage(sender, {
        text: `🎉 Subdomain ${subdomain} dengan IP VPS ${ipvps} berhasil ditambahkan ke domain ${selectedDomain.name}!`
      });
    });
  } catch (error) {
    console.log("Error menambah subdomain:", error);
    await kelzhost.sendMessage(sender, { text: "❌ Terjadi kesalahan saat menambahkan subdomain. Coba lagi nanti." });
  }
}

module.exports = { listDomain, addSubdomain };