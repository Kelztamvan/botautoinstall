const fs = require("fs");
const { prefix } = require("../../setting");

async function removeSubdomain(kelzhost, sender, text) {
  const domainData = text.trim().split(' '); // Format: removeSubdomain <domain_name> <subdomain_name>

  if (domainData.length !== 2) {
    // Jika format tidak benar, beri tahu pengguna
    await kelzhost.sendMessage(sender, { text: `❌ *Format yang benar*: ${prefix}removesubdomain <domain_name> <subdomain_name>` });
    return;
  }

  const domainName = domainData[0].trim();
  const subdomainName = domainData[1].trim();

  const filePath = "./data/domains.json";
  let domains = [];

  try {
    if (fs.existsSync(filePath)) {
      const data = await fs.promises.readFile(filePath, "utf8");
      domains = JSON.parse(data).domains;  // Ambil data domain
    }

    const domainIndex = domains.findIndex(domain => domain.name === domainName); // Memeriksa apakah domain ada
    if (domainIndex === -1) {
      await kelzhost.sendMessage(sender, { text: `⚠️ Domain *${domainName}* tidak ditemukan.` });
      return;
    }

    // Mencari subdomain dalam domain
    const subdomainIndex = domains[domainIndex].subdomains.findIndex(subdomain => subdomain.subdomain === subdomainName);
    if (subdomainIndex === -1) {
      await kelzhost.sendMessage(sender, { text: `⚠️ Subdomain *${subdomainName}* tidak ditemukan pada domain *${domainName}*.` });
      return;
    }

    // Menghapus subdomain
    domains[domainIndex].subdomains.splice(subdomainIndex, 1);

    // Menyimpan data yang sudah diperbarui
    await fs.promises.writeFile(filePath, JSON.stringify({ domains }, null, 2), "utf8");

    await kelzhost.sendMessage(sender, {
      text: `🎉 Subdomain *${subdomainName}* berhasil dihapus dari domain *${domainName}*`
    });
  } catch (error) {
    console.log("Error menghapus subdomain:", error);
    await kelzhost.sendMessage(sender, { text: "❌ Terjadi kesalahan saat menghapus subdomain. Coba lagi nanti." });
  }
}

module.exports = { removeSubdomain };