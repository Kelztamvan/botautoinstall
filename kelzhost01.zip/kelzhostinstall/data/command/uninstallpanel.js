const { Client } = require('ssh2');
const { generateRandomPassword } = require('../helpers/password'); // Menghasilkan password acak
const { bash } = require('../../setting'); // Mengimpor file setting.js

// Fungsi pengiriman pesan
async function sendMessage(sender, message) {
    // Ganti dengan pengiriman pesan yang sesuai
    console.log(`Kepada: ${sender} - ${message.text}`);
}

// Fungsi untuk menghapus instalasi Wings
async function uninstallWings(sender, text) {
    const t = text.split(',');
    if (t.length < 2) {
        return sendMessage(sender, { text: `*Format salah!*\nPenggunaan: ${prefix}uninstallwings vps,passwordvps (Contoh: 192.168.1.1, password123)` });
    }

    const vps = t[0];            // IP VPS
    const passwdvps = t[1];      // Password VPS
    
    // Konfigurasi koneksi SSH ke VPS
    const connSettings = {
        host: vps,
        port: '22',
        username: 'root',
        password: passwdvps,
    };

    // Perintah untuk menghapus Wings dan panel
    const commandUninstall = 'bash <(curl -s https://pterodactyl-installer.se) uninstall';

    const conn = new Client();

    // Menghubungkan ke VPS
    conn.on('ready', () => {
        sendMessage(sender, { text: '`PROSES UNINSTALL WINGS TUNGGU YA MANIEZ`' });

        // Eksekusi perintah untuk menghapus Wings
        conn.exec(commandUninstall, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Uninstall stream closed with code ' + code + ' and signal ' + signal);
                sendMessage(sender, { text: '`WINGS BERHASIL DIUNINSTALL!`' });
                conn.end();
            }).on('data', (data) => {
                handleUninstallInput(data, stream);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).connect(connSettings);

    // Fungsi untuk menangani input dalam proses uninstall
    function handleUninstallInput(data, stream) {
        if (data.toString().includes('Input')) {
            stream.write('y\n'); // Mengkonfirmasi penghapusan
        }
        console.log('STDOUT: ' + data);
    }
}

// Fungsi untuk generate password acak (misalnya untuk panel)
function generateRandomPassword() {
    const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-+=<>?";
    let password = "";
    for (let i = 0; i < 16; i++) {
        password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
}

module.exports = { uninstallWings, generateRandomPassword };