const fs = require("fs");
const { prefix } = require("../../setting");
const { addReseller } = require("../command/addreseller");
const { checkReseller } = require("../command/checkreseller");
const { removeReseller } = require("../command/removereseller");

async function handleResellerMenu(kelzhost, sender, prefix) {
  try {
    const menu = `
      ┏━ ⊑ *RESELLER MENU BY KELZHOSTING* ⊒
      ┃ ${prefix}addreseller
      ┃ ${prefix}checkreseller
      ┃ ${prefix}removereseller
      ┗━━━━━━━━━━━━━━
    `;
    
    await kelzhost.sendMessage(sender, { text: menu });
    
    // Menunggu respon pengguna untuk perintah lebih lanjut
    kelzhost.ev.on("messages.upsert", async (m) => {
      const message = m.messages[0];
      const text = message.message.conversation || "";
      
      if (!message.key.fromMe && message.key.remoteJid === sender) {
        if (text.startsWith(`${prefix}addreseller`)) {
          await addReseller(kelzhost, sender, text);
        } else if (text === `${prefix}checkreseller`) {
          await checkReseller(kelzhost, sender, prefix);
        } else if (text.startsWith(`${prefix}removereseller`)) {
          await removeReseller(kelzhost, sender, text);
        } else if (text === `${prefix}exit`) {
          await kelzhost.sendMessage(sender, { text: "Anda keluar dari Reseller Menu." });
        } else {
          await kelzhost.sendMessage(sender, { text: "Perintah tidak dikenali. Ketik 'menu' untuk melihat opsi." });
        }
      }
    });
  } catch (error) {
    console.log("Error dalam menangani perintah menu reseller:", error);
    await kelzhost.sendMessage(sender, { text: "Terjadi kesalahan, coba lagi nanti." });
  }
}

module.exports = { handleResellerMenu };