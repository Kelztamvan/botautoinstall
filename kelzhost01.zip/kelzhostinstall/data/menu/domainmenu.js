const fs = require("fs");
const { prefix } = require("../../setting");
const { addDomain } = require("../command/adddomain");
const { checkDomain } = require("../command/checkdomain");
const { removeDomain } = require("../command/removedomain");

async function handleDomainMenu(kelzhost, sender, prefix) {
  try {
    const menu = `
      ┏━ ⊑ *DOMAIN MENU BY KELZHOSTING* ⊒
      ┃ ${prefix}adddomain
      ┃ ${prefix}checkdomain
      ┃ ${prefix}removedomain
      ┗━━━━━━━━━━━━━━
    `;
    
    await kelzhost.sendMessage(sender, { text: menu });
    
    // Menunggu respon pengguna untuk perintah lebih lanjut
    kelzhost.ev.on("messages.upsert", async (m) => {
      const message = m.messages[0];
      const text = message.message.conversation || "";
      
      if (!message.key.fromMe && message.key.remoteJid === sender) {
        if (text.startsWith(`${prefix}adddomain`)) {
          await addDomain(kelzhost, sender, text);
        } else if (text === `${prefix}checkdomain`) {
          await checkDomain(kelzhost, sender, prefix);
        } else if (text.startsWith(`${prefix}removedomain`)) {
          await removeDomain(kelzhost, sender, text);
        } else if (text === `${prefix}exit`) {
          await kelzhost.sendMessage(sender, { text: "Anda keluar dari Domain Menu." });
        } else {
          await kelzhost.sendMessage(sender, { text: "Perintah tidak dikenali. Ketik 'menu' untuk melihat opsi." });
        }
      }
    });
  } catch (error) {
    console.log("Error dalam menangani perintah menu domain:", error);
    await kelzhost.sendMessage(sender, { text: "Terjadi kesalahan, coba lagi nanti." });
  }
}

module.exports = { handleDomainMenu };