const fs = require("fs");
const { prefix } = require("../../setting");
const { installPterodactylPanel } = require("../command/installpanel");
const { uninstallPterodactylPanel } = require("../command/uninstallpanel");
const { startWings } = require("../command/startwings");
const { installTheme } = require("../command/installtheme");

async function handlePterodactylMenu(kelzhost, sender, prefix) {
  try {
    const menu = `
      ┏━ ⊑ *PTERODACTYL MENU BY KELZHOSTING* ⊒
      ┃ ${prefix}installpanel
      ┃ ${prefix}uninstallpanel
      ┃ ${prefix}startwings
      ┃ ${prefix}installtheme
      ┗━━━━━━━━━━━━━━
    `;
    
    await kelzhost.sendMessage(sender, { text: menu });
    
    // Menunggu respon pengguna untuk perintah lebih lanjut
    kelzhost.ev.on("messages.upsert", async (m) => {
      const message = m.messages[0];
      const text = message.message.conversation || "";
      
      if (!message.key.fromMe && message.key.remoteJid === sender) {
        if (text.startsWith(`${prefix}installpanel`)) {
          await installPterodactylPanel(kelzhost, sender, text);
        } else if (text.startsWith(`${prefix}uninstallpanel`)) {
          await uninstallPterodactylPanel(kelzhost, sender, text);
        } else if (text.startsWith(`${prefix}startwings`)) {
          await startWings(kelzhost, sender, text);
        } else if (text.startsWith(`${prefix}installtheme`)) {
          await installTheme(kelzhost, sender, text);
        } else if (text === `${prefix}exit`) {
          await kelzhost.sendMessage(sender, { text: "Anda keluar dari Pterodactyl Menu." });
        } else {
          await kelzhost.sendMessage(sender, { text: "Perintah tidak dikenali. Ketik 'menu' untuk melihat opsi." });
        }
      }
    });
  } catch (error) {
    console.log("Error dalam menangani perintah menu pterodactyl:", error);
    await kelzhost.sendMessage(sender, { text: "Terjadi kesalahan, coba lagi nanti." });
  }
}

module.exports = { handlePterodactylMenu };