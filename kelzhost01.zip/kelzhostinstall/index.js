const pino = require("pino");
const path = require("path");
const fs = require("fs-extra");
const chalk = require("chalk");
const readline = require("readline");
const CFonts = require("cfonts");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  delay,
} = require("@whiskeysockets/baileys");
const {
  handleMenu,
  handleAddReseller,
  handleAddPanelMenu,
  handleAddResellerMenu,
  handleExit,
} = require("./kelzhost");
const { ownerId, prefix } = require("./setting");
const axios = require("axios");

// Fungsi addDomain
async function addDomain(kelzhost, sender, text) {
  const domain = text.split(" ")[1];
  if (!domain) {
    return kelzhost.sendMessage(sender, {
      text: "⚠️ Harap masukkan domain yang valid setelah perintah!",
    });
  }

  const domains = await getDomains();
  if (domains.length >= 4) {
    return kelzhost.sendMessage(sender, {
      text: "⚠️ Anda sudah mencapai batas maksimal domain (4).",
    });
  }

  domains.push(domain);
  await saveDomains(domains);

  try {
    const response = await axios.post("https://api.example.com/addDomain", {
      domain: domain,
    });
    if (response.status === 200) {
      kelzhost.sendMessage(sender, {
        text: `✅ Domain ${domain} berhasil ditambahkan ke server.`,
      });
    } else {
      kelzhost.sendMessage(sender, {
        text: `⚠️ Terjadi masalah saat menambahkan domain ke server.`,
      });
    }
  } catch (error) {
    console.error("Error mengirim data ke server:", error);
    kelzhost.sendMessage(sender, {
      text: "⚠️ Terjadi kesalahan saat menghubungi server.",
    });
  }
}

// Fungsi untuk mengambil daftar domain yang ada
async function getDomains() {
  const domainFile = "./domains.json";
  try {
    if (fs.existsSync(domainFile)) {
      return JSON.parse(fs.readFileSync(domainFile));
    }
    return [];
  } catch (error) {
    console.error("Error membaca file domain:", error);
    return [];
  }
}

// Fungsi untuk menyimpan domain yang ada
async function saveDomains(domains) {
  const domainFile = "./domains.json";
  try {
    fs.writeFileSync(domainFile, JSON.stringify(domains, null, 2));
  } catch (error) {
    console.error("Error menyimpan file domain:", error);
  }
}

global.sessionName = "kelzsession";
const pairingCode = process.argv.includes("--use-pairing-code");

if (!pairingCode) {
  console.log(chalk.redBright("Gunakan argumen --use-pairing-code"));
  process.exit(1);
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const question = (text) =>
  new Promise((resolve) => rl.question(text, resolve));

CFonts.say("kelz pairing", {
  font: "tiny",
  align: "center",
  colors: ["system"],
});
CFonts.say(
  "Mudah untuk Menghubungkan Bot WhatsApp Menggunakan Pairing Code\nDengan Baileys Library\n\nGithub : https://github.com/kelz/kelz",
  {
    colors: ["system"],
    font: "console",
    align: "center",
  }
);

async function main() {
  const sessionExists = await fs.pathExists(
    path.join(__dirname, global.sessionName)
  );
  if (sessionExists) {
    console.log(chalk.greenBright("Membersihkan sesi lama..."));
    await fs.emptyDir(path.join(__dirname, global.sessionName));
    await delay(800);
    kelzhostPairing();
  } else {
    console.log(chalk.greenBright("Memulai Proses Pairing..."));
    kelzhostPairing();
  }
}

async function kelzhostPairing() {
  const { state, saveCreds } = await useMultiFileAuthState(
    "./" + global.sessionName
  );
  try {
    const socket = makeWASocket({
      printQRInTerminal: !pairingCode,
      logger: pino({
        level: "silent",
      }),
      browser: ["Chrome (Linux)", "", ""],
      auth: state,
    });

    if (pairingCode && !socket.authState.creds.registered) {
      let phoneNumber = await question(
        chalk.bgBlack(chalk.greenBright("⚠️ MASUKKAN NOMOR ANDA (FORMAT INTERNASIONAL): "))
      );
      phoneNumber = phoneNumber.replace(/[^0-9]/g, ""); // Menghapus karakter non-angka

      while (!phoneNumber) {
        console.log(chalk.bgBlack(chalk.redBright("❌ Nomor tidak valid! Harap masukkan nomor yang benar.")));
        phoneNumber = await question(
          chalk.bgBlack(chalk.greenBright("⚠️ MASUKKAN NOMOR ANDA (FORMAT INTERNASIONAL): "))
        );
        phoneNumber = phoneNumber.replace(/[^0-9]/g, "");
      }

      setTimeout(async () => {
        let code = await socket.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(
          chalk.black(chalk.bgGreen("✅ KODE PAIRING ANDA:")),
          chalk.whiteBright(code)
        );
      }, 3000);
    }

    socket.ev.on(
      "connection.update",
      async ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          let file = await kelzhost.sendMessage(socket.user.id, {
            document: fs.readFileSync("./" + global.sessionName + "/creds.json"),
            mimetype: "json",
            fileName: "creds.json",
          });

          await kelzhost.sendMessage(
            socket.user.id,
            {
              text: "Unggah sesi ini ke state multi-auth bot Anda",
            },
            { quoted: file }
          );

          console.log(chalk.greenBright("DONE!"));
          await fs.emptyDir("./" + global.sessionName);
          process.exit(1);
        } else if (
          connection === "close" &&
          lastDisconnect &&
          lastDisconnect.error &&
          lastDisconnect.error.output.statusCode &&
          lastDisconnect.error.output.statusCode !== 401
        ) {
          console.log(chalk.redBright("Koneksi gagal, mencoba ulang..."));
          kelzhostPairing();
        }
      }
    );

    socket.ev.on("creds.update", saveCreds);

    socket.ev.on("messages.upsert", async (m) => {
      const message = m.messages[0];
      if (!message.key.fromMe && message.message) {
        const sender = message.key.remoteJid;
        const text = message.message.conversation || "";

        if (sender === ownerId) {
          if (text.startsWith(`${prefix}adddomain`)) {
            await addDomain(kelzhost, sender, text);
          } else {
            await kelzhost.handleMenu(socket, sender, text, prefix);
          }
        } else {
          await kelzhost.sendMessage(sender, {
            text: "⚠️ Anda bukan owner bot.",
          });
        }
      }
    });
  } catch (error) {
    console.error("Error pairing:", error);
    await fs.emptyDir("./" + global.sessionName);
    process.exit(1);
  }
}

main().catch((error) => console.error("Error:", error));