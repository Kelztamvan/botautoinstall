const fs = require("fs");
const { ownerId, prefix } = require("./setting");

const { handleResellerMenu } = require("./data/menu/resellermenu");
const { handleDomainMenu } = require("./data/menu/domainmenu");
const { handlePterodactylMenu } = require("./data/menu/pterodactylmenu");

const { addDomain } = require("./data/command/adddomain");
const { checkDomain } = require("./data/command/checkdomain");
const { removeDomain } = require("./data/command/removedomain");
const { addReseller } = require("./data/command/addreseller");
const { checkReseller } = require("./data/command/checkreseller");
const { removeReseller } = require("./data/command/removereseller");

async function handleMenu(kelzhost, sender, text, prefix) {
  try {
    const isOwner = sender === ownerId;
    const isReseller = await checkReseller(sender);

    if (!text) {
      await kelzhost.sendMessage(sender, { text: "Perintah tidak boleh kosong." });
      return;
    }

    switch (text.toLowerCase()) {
      case "menu":
        if (isOwner || isReseller) {
          const menu = `
          ┏━ ⊑ *MENU BY KELZHOSTING* ⊒
          ┃ ${prefix}resellermenu
          ┃ ${prefix}info bot
          ┃ ${prefix}domainmenu
          ┃ ${prefix}pterodactylmenu
          ┃ ${prefix}exit
          ┗━━━━━━━━━━━━━━
          `;
          await kelzhost.sendMessage(sender, { text: menu });
        } else {
          await kelzhost.sendMessage(sender, { text: "Anda tidak memiliki akses ke menu ini." });
        }
        break;

      case "resellermenu":
        await handleResellerMenu(kelzhost, sender, prefix);
        break;

      case "domainmenu":
        await handleDomainMenu(kelzhost, sender, prefix);
        break;

      case "pterodactylmenu":
        await handlePterodactylMenu(kelzhost, sender, prefix);
        break;

      case "adddomain":
        await addDomain(kelzhost, sender, prefix);
        break;

      case "checkdomain":
        await checkDomain(kelzhost, sender, prefix);
        break;

      case "removedomain":
        await removeDomain(kelzhost, sender, prefix);
        break;

      case "addreseller":
        await addReseller(kelzhost, sender, prefix);
        break;

      case "checkreseller":
        await checkReseller(kelzhost, sender, prefix);
        break;

      case "removereseller":
        await removeReseller(kelzhost, sender, prefix);
        break;

      case "exit":
        await handleExit(kelzhost, sender);
        break;

      default:
        await kelzhost.sendMessage(sender, { text: "Perintah tidak dikenali. Ketik 'menu' untuk melihat opsi." });
        break;
    }
  } catch (error) {
    console.log("Error dalam menangani perintah:", error);
    await kelzhost.sendMessage(sender, { text: "Terjadi kesalahan, coba lagi nanti." });
  }
}

async function handleExit(kelzhost, sender) {
  await kelzhost.sendMessage(sender, { text: "Terima kasih telah menggunakan bot ini! Bot akan keluar." });
  process.exit(0);
}

module.exports = { handleMenu };