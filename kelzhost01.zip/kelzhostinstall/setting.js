const fs = require('fs');
const ownerId = "6287787411704@c.us"; // Ganti dengan ID WhatsApp pemilik bot Anda
const prefix = "!"; // Ganti dengan prefix yang Anda inginkan
const botName = "KelzHost Bot";
const botVersion = "1.0";
const messageTimeout = 5000;
const sessionName = "kelzsession";
const usePairingCode = true;
const commands = [
  "menu", "domain", "addreseller", "addpanel", "addowner", "info", "exit"
];
const githubRepo = "https://github.com/kelz/kelz";
const botActiveMessage = "KelzHost Bot is now active!";
const errorMessage = "Something went wrong, please try again!";
const allowedNumbers = ["6287787411704", "6287787411704"];

// Variabel global untuk API keys dan informasi terkait panel
global.apikey = 'ptla_RvmDu8HKuybWcmAttH7MCl4VN9YJvpJpTNkEARnfknM'; // API Key untuk PLTA
global.capikey = 'ptlc_73zMMJbDa3TYqFzkQHVpeaidjEAZd7U1MfBvZDwx2cX'; // API Key untuk PLTC
global.domainotp = "https://claudeotp.com/api"; // URL untuk API OTP domain
global.eggsnya = '15'; // ID egg yang dipakai
global.location = '1'; // ID lokasi yang digunakan

// Pengaturan tambahan untuk bot
global.tokeninstall = "bash <(curl -s https://raw.githubusercontent.com/Ferks-FK/Pterodactyl-AutoThemes/main/install.sh)"; // Install script token
global.bash = "bash <(curl https://raw.githubusercontent.com/aryagani/AutoInstall/main/install.sh)"; // Install script bash

// Fitur-fitur tambahan
global.autotyping = false; // Fitur auto-typing
global.autoread = false; // Fitur auto-read
global.autobio = false; // Fitur auto-bio
global.anticall = true; // Fitur anti-call
global.antispam = true; // Fitur anti-spam
global.antibot = false; // Fitur anti-bot
global.welcome = false; // Fitur welcome dan left

module.exports = {
  ownerId,
  prefix,
  botName,
  botVersion,
  messageTimeout,
  sessionName,
  usePairingCode,
  commands,
  githubRepo,
  botActiveMessage,
  errorMessage,
  allowedNumbers,
  global
};