# Kelzhost - Bot API WhatsApp untuk Instalasi Pterodactyl Panel

Kelzhost adalah bot yang dirancang untuk mengotomatiskan instalasi Pterodactyl Panel dan Wings pada VPS melalui API WhatsApp, menggunakan pustaka Baileys. Bot ini bertujuan untuk menyederhanakan proses instalasi dan konfigurasi sistem panel Pterodactyl langsung dari WhatsApp.

## Fitur

- Mengotomatiskan instalasi Pterodactyl Panel.
- Instalasi dan konfigurasi Pterodactyl Wings.
- Membuat node VPS untuk Pterodactyl.
- Mengirimkan detail panel (username, password, URL login) setelah instalasi selesai.
- Proses interaktif melalui WhatsApp, memandu pengguna melalui langkah-langkah instalasi.

## Prasyarat

Untuk menjalankan bot ini, Anda memerlukan hal-hal berikut:

- Node.js (v14 atau lebih tinggi)
- VPS dengan akses SSH
- Akun WhatsApp untuk bot
- Akses ke skrip penginstal Pterodactyl

## Instalasi

### 1. Clone repositori

Pertama, clone repositori ke mesin lokal atau VPS Anda:

```bash
git clone https://github.com/kelzhost/kelzhost.git
cd kelzhost